<?php echo e($slot); ?>

<?php /**PATH D:\laragon\www\arthiworth-backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>