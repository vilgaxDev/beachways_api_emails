<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\laragon\www\arthiworth-backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>