<?php $__env->startComponent('mail::message'); ?>
# Thank You for Subscribing!

Hi <?php echo new \Illuminate\Support\EncodedHtmlString($subscriber->email); ?>,

Thank you for subscribing to our newsletter. You are now part of our community!

We will keep you updated with the latest properties and news.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\laragon\www\arthiworth-backend\resources\views/emails/subscription_confirmation.blade.php ENDPATH**/ ?>